#include "GraphUI.hpp"

int main() {
    graphUI();
}